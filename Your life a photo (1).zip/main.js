//slider

let leftArrow = document.querySelector(".left-arrow")
let rightArrow = document.querySelector(".right-arrow")
let slider = document.querySelectorAll(".our__item")

let currentImage = 0

rightArrow.addEventListener("click" , function(){
    if(currentImage != slider.length -1) {
        slider[currentImage].classList.remove("active")
        currentImage++
        slider[currentImage].classList.add("active")
    }
})

leftArrow.addEventListener("click" , function(){
    if(currentImage != 0) {
        slider[currentImage].classList.remove("active")
        currentImage--
        slider[currentImage].classList.add("active")
    }
})

// Menu

let menuBtn = document.querySelector(".nav-toggle")

let linkMenu = document.querySelector(".link-menu")

menuBtn.addEventListener("click", function(){
    menuBtn.classList.toggle("activel");
    linkMenu.classList.toggle("active")
})

// scroll

let anchors = document.querySelectorAll('a[href*="#"]');

for(let anchor of anchors) {
    anchor.addEventListener("click", function(e){
        e.preventDefault();

        let blockId = anchor.getAttribute('href').substr(1);

        document.getElementById(blockId).scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        }) 
    })
}

//header__fixed//

let header = document.querySelector(".header");
let intro = document.querySelector(".intro");
let headerHeight = header.offsetHeight;
console.log(headerHeight);
let introHeight = intro.offsetHeight;
console.log(introHeight);

window.addEventListener("scroll", () => {
    let scrollDistance = window.scrollY;
    console.log(scrollDistance);

    if(scrollDistance >= introHeight) {
        header.classList.add("fixed");
        intro.style.marginTop =`${headerHeight}px`;
    }else {
        header.classList.remove("fixed");
        intro.style.marginTop = null;
    }
})
